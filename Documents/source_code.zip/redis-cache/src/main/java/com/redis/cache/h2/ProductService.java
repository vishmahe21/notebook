package com.redis.cache.h2;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

	@Autowired
	ProductRepository repository;

	public ProductEntity createProduct(ProductEntity product) {
		return repository.save(product);
	}

	public ProductEntity getProduct(int id) {
		Optional<ProductEntity> productOptional = repository.findById(id);
		return productOptional.get();
	}

	public void deleteEntity(int id) {
		repository.deleteById(id);
	}

	public ProductEntity updateProduct(ProductEntity product) {
		return repository.save(product);
	}

	public List<ProductEntity> findAllProducts() {
		return repository.findAll();
	}

}
