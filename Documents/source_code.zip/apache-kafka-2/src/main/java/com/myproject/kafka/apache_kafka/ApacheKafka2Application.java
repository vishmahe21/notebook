package com.myproject.kafka.apache_kafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApacheKafka2Application {

	public static void main(String[] args) {
		SpringApplication.run(ApacheKafka2Application.class, args);
	}

}
