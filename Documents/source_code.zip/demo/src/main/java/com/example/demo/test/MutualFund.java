package com.example.demo.test;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/mf")
public class MutualFund {

	@PostMapping("/convertToExcel")
	public ResponseEntity<String> convertFundToExcel(@RequestBody Map<String, Object> data) {
		try {
			String message = exportingToExcel(data);
			return new ResponseEntity<String>(message, HttpStatus.OK);
		} catch (Exception ex) {
			return new ResponseEntity<String>(ex.getMessage(), HttpStatus.BAD_REQUEST);
		}

	}

	protected String exportingToExcel(Map<String, Object> data) throws IOException {
		Map<String, Object> dataMap = (Map<String, Object>) data.get("data");
		File file = new File("D:/Others/mutual_funds/MFDetails.xlsx");

		if (MapUtils.isNotEmpty(dataMap)) {
			// workbook object
			HSSFWorkbook workbook = new HSSFWorkbook();
			// spreadsheet object
			HSSFSheet spreadsheet = workbook.createSheet(String.valueOf(dataMap.get("fund_name")));
			// creating a row object
			HSSFRow frow;

			// Create headers
			frow = spreadsheet.createRow(0);
			int fcellid = 0;
			Cell fcell = frow.createCell(fcellid++);
			fcell.setCellValue("S.No.");
			fcell = frow.createCell(fcellid++);
			fcell.setCellValue("Amount");
			fcell = frow.createCell(fcellid++);
			fcell.setCellValue("Units");
			fcell = frow.createCell(fcellid++);
			fcell.setCellValue("NAV Price");
			fcell = frow.createCell(fcellid++);
			fcell.setCellValue("Type");
			fcell = frow.createCell(fcellid++);
			fcell.setCellValue("Source");
			fcell = frow.createCell(fcellid++);
			fcell.setCellValue("Date");

			List<Map<String, Object>> transactionList = (List<Map<String, Object>>) dataMap.get("transaction_list");
			if (CollectionUtils.isNotEmpty(transactionList)) {
				int rowid = 1;
				for (int i = 0; i < transactionList.size(); i++) {
					Map<String, Object> trans = transactionList.get(i);
					HSSFRow row = spreadsheet.createRow(rowid++);
					int cellid = 0;
					Cell cell = row.createCell(cellid++);
					cell.setCellValue(cellid);
					cell = row.createCell(cellid++);
					cell.setCellValue(Double.parseDouble(String.valueOf(trans.get("transaction_amount"))));
					cell = row.createCell(cellid++);
					cell.setCellValue(Double.parseDouble(String.valueOf(trans.get("units"))));
					cell = row.createCell(cellid++);
					cell.setCellValue(Double.parseDouble(String.valueOf(trans.get("transaction_price"))));
					cell = row.createCell(cellid++);
					cell.setCellValue(String.valueOf(trans.get("remark")));
					cell = row.createCell(cellid++);
					cell.setCellValue(String.valueOf(trans.get("transaction_source")));
					cell = row.createCell(cellid++);
					cell.setCellValue(LocalDateTime.parse(String.valueOf(trans.get("transaction_time"))));
				}
			}

			workbook.write(file);
			workbook.close();
		}

		// .xlsx is the format for Excel Sheets...
		// writing the workbook into the file...

		return "Workbook Updated";
	}

}
