package com.example.demo.test;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Test {

	static Logger log = LoggerFactory.getLogger(Test.class);

	public static void main(String[] args) {
		String s = "ababaab";
		String[] words = { "ab", "ba", "ba" };

		List<Integer> res = new Test().findSubstring(s, words);
		log.info("Result: {}", res);
	}

	public List<Integer> findSubstring(String s, String[] words) {
		List<Integer> res = new ArrayList<>();
		int wlen = words[0].length();
		int len = wlen * words.length;
		int maxIndex = s.length() - len;

		for (int i = 0; i <= maxIndex; i++) {
			StringBuilder part = new StringBuilder(s.substring(i, i + len));
			int j = -1;
			int index;
			while (++j < words.length && (index = part.indexOf(words[j])) != -1) {
				part = part.delete(index, index + wlen);
			}
			if (j == words.length) {
				res.add(i);
			}
		}

		return res;
	}

}
