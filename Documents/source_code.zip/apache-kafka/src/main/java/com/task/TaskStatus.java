package com.task;

public enum TaskStatus {
	CREATED, APPROVED, REJECTED, BLOCKED, DONE
}
