package com.task;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/tasks")
public class TaskController {
	private final TaskRepository repository;

	@Autowired
	public TaskController(TaskRepository repository) {
		this.repository = repository;
	}

	@PostMapping(value = "")
	public ResponseEntity<Object> createTask(@RequestBody TaskDto taskDto) {
		try {
			Task task = mapToTask(taskDto);

			Task savedTask = repository.save(task);
			return new ResponseEntity<>(savedTask.getId(), HttpStatus.OK);
		} catch (Exception ex) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

	}

	@GetMapping(value = "/{id}")
	public ResponseEntity<Object> getTask(@PathVariable(name = "id") String id) {
		Optional<Task> taskOptional = repository.findById(Long.parseLong(id));
		if (taskOptional.isPresent()) {
			return new ResponseEntity<>(mapToTaskDto(taskOptional.get()), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}

	@PutMapping(value = "/{id}")
	public ResponseEntity<Object> updateTask(@PathVariable(name = "id") String id, @RequestBody TaskDto taskDto) {
		Optional<Task> taskOptional = repository.findById(Long.parseLong(id));

		if (taskOptional.isPresent()) {
			Task task = taskOptional.get();
			if (Objects.nonNull(taskDto.getDescription())) {
				task.setDescription(taskDto.getDescription());
			}
			if (Objects.nonNull(taskDto.getTitle())) {
				task.setTitle(taskDto.getTitle());
			}
			if (Objects.nonNull(taskDto.getStatus())) {
				try {
					task.setTaskStatus(TaskStatus.valueOf(taskDto.getStatus()));
				} catch (IllegalArgumentException ex) {
					return new ResponseEntity<>("Available statuses are: CREATED,APPROVED,REJECTED,BLOCKED,DONE.",
							HttpStatus.OK);
				}

			}

			repository.save(task);
			return new ResponseEntity<>(HttpStatus.OK);

		} else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}

	@DeleteMapping(value = "/{id}")
	public ResponseEntity<Object> deleteTask(@PathVariable(name = "id") String id) {
		Optional<Task> taskOptional = repository.findById(Long.parseLong(id));
		if (taskOptional.isPresent()) {
			repository.deleteById(Long.parseLong(id));
			return new ResponseEntity<>(HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}

	@GetMapping(value = "/describe/{id}")
	public ResponseEntity<Object> getTaskDescription(@PathVariable(name = "id") String id) {
		String message = null;
		Optional<Task> taskOptional = repository.findById(Long.parseLong(id));
		if (taskOptional.isPresent()) {
			TaskDto task = taskOptional.get().toDto();
			message = String.format("Description of Task [%s: %s] is: %s", String.valueOf(task.getId()),
					task.getTitle(), task.getDescription());

		} else {
			message = String.format("Task with id = %s does not exist", id);
		}

		return new ResponseEntity<>(message, HttpStatus.OK);
	}

	@GetMapping(value = "")
	public ResponseEntity<Object> getAllTasks() {
		List<Task> tasks = (List<Task>) repository.findAll();
		List<TaskDto> taskDtos = new ArrayList<>();
		if (tasks != null)
			tasks.stream().forEach(t -> taskDtos.add(t.toDto()));

		return new ResponseEntity<>(taskDtos, HttpStatus.OK);
	}

	@GetMapping(value = "/describe")
	public ResponseEntity<Object> getAllTaskDescriptions() {
		List<String> messages = new ArrayList<>();
		List<Task> tasks = (List<Task>) repository.findAll();
		List<TaskDto> taskDtos = new ArrayList<>();

		if (tasks != null) {
			tasks.stream().forEach(t -> taskDtos.add(t.toDto()));
			taskDtos.stream().forEach(task -> messages.add(String.format("Description of Task [%s: %s] is: %s",
					String.valueOf(task.getId()), task.getTitle(), task.getDescription())));
		}

		return new ResponseEntity<>(messages, HttpStatus.OK);
	}

	private TaskDto mapToTaskDto(Task task) {
		return task.toDto();
	}

	private Task mapToTask(TaskDto taskDto) {
		Task task = new Task(taskDto.getTitle());
		task.setDescription(taskDto.getDescription());
		task.setTaskStatus(TaskStatus.valueOf(taskDto.getStatus()));
		return task;
	}

}