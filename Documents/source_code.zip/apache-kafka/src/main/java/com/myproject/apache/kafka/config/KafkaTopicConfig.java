package com.myproject.apache.kafka.config;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

import com.myproject.apache.kafka.constants.GenericConstants;

@Configuration
public class KafkaTopicConfig {

	@Bean
	public NewTopic createTopic() {
		return TopicBuilder.name(GenericConstants.FIRST_TOPIC).build();

	}
}
