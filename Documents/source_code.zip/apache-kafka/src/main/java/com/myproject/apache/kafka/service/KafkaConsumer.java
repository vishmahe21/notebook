package com.myproject.apache.kafka.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.myproject.apache.kafka.constants.GenericConstants;

@Service
public class KafkaConsumer {

	private Logger log = LoggerFactory.getLogger(KafkaConsumer.class);

	@KafkaListener(topics = GenericConstants.FIRST_TOPIC, groupId = "group1")
	public void receiveMessage(String message) {
		log.info("Message received --> {}", message);
	}

}
