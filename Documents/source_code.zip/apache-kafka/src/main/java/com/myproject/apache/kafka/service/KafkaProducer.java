package com.myproject.apache.kafka.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.myproject.apache.kafka.constants.GenericConstants;

@Service
public class KafkaProducer {

	private Logger log = LoggerFactory.getLogger(KafkaProducer.class);

	private KafkaTemplate<String, String> kafkaTemplate;

	public KafkaProducer(KafkaTemplate<String, String> kafkaTemplate) {
		this.kafkaTemplate = kafkaTemplate;
	}

	public void sendMessage(String message) {
		log.info("Message send : {}", message);
		kafkaTemplate.send(GenericConstants.FIRST_TOPIC, message);
	}

}
