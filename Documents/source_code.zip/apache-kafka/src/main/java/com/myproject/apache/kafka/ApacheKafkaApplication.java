package com.myproject.apache.kafka;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.myproject.apache.kafka.service.KafkaProducer;

@SpringBootApplication(exclude = KafkaProducer.class, scanBasePackages = "com.*")
@ComponentScan(excludeFilters = @ComponentScan.Filter(value = {KafkaProducer.class}), basePackages = "com.*")
public class ApacheKafkaApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(ApacheKafkaApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
