package com.myproject.apache.kafka.constants;

public class GenericConstants {
	
	public static final String FIRST_TOPIC = "topic1";

}
