package com.example.microservices.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "department")
public class DepartmentEntity {
	
	private String id;
	
	private String name;
	

}
