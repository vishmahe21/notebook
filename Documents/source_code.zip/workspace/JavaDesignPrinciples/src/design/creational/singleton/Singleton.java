package design.creational.singleton;

import java.util.Objects;

public class Singleton {

	private static Singleton object;

	private Singleton() {
	}

	public Singleton getInstance() {
		return Objects.nonNull(object) ? object : new Singleton();
	}

}
