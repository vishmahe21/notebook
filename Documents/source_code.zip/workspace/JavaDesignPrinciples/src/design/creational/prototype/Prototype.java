package design.creational.prototype;

public class Prototype {

}
