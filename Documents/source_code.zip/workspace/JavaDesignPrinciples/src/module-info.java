/**
 * 
 */
/**
 * 
 */
module JavaDesignPrinciples {
}