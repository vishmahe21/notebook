package com.leetcode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collectors;

public class Anagrams {

	public static void main(String[] args) {
		String[] arr = { "dog", "fog", "god", "gof", "god", "fool", "gof", "loof" };

		System.out.println(new Anagrams().findAnagrams(arr));

	}

	private List<String> findAnagrams(String[] arr) {
		LinkedHashMap<String, List<String>> map = new LinkedHashMap<>();

		for (String s : arr) {
			String reverse = null;
			if (map.get(s) != null) {
				map.get(s).add(s);
			} else if (map.get(reverse = reverse(s)) != null) {
				map.get(reverse).add(s);
			} else {
				map.put(s, new ArrayList<>(Arrays.asList(s)));
			}
		}

		return map.values().stream().flatMap(List::stream).collect(Collectors.toList());

	}

	private static String reverse(String s) {
		return new StringBuilder(s).reverse().toString();
	}

}
