package com.leetcode;

public class LinkedList {
	public static void main(String[] args) {
		Node head = new Node(10, null);
		Node p = head;
		for(int i=2; i<=5; i++) {
			Node node = new Node(i*10, null);
			p.next = node;
			p = node;
		}
		
		//Traversal
		p = head;
		while(p != null) {
			System.out.print(p.value + ", ");
			p = p.next;
		}
	}

}

class Node{
	Object value;
	Node next;
	
	public Node(Object value, Node next) {
		this.value = value;
		this.next = next;
	}
}


