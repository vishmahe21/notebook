package com.leetcode;

import java.util.Stack;

public class InfixToPostfix {

	public static void main(String[] args) {
		String exp = "2+3*5+8-6*9";
		exp = "2+3*5^3+6-3*2";
		InfixToPostfix itp = new InfixToPostfix();
		String postfix = itp.generatePostfix(exp);
		System.out.println(postfix);

	}

	public String generatePostfix(String exp) {
		Stack<Character> stack = new Stack<>();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < exp.length(); i++) {
			char ch = exp.charAt(i);
			if (isOperand(ch)) {
				sb.append(ch);
			} else if (isOperator(ch)) {
				if (stack.isEmpty() || isHigherPrecedence(ch, stack.peek())) {
					stack.push(ch);
				} else {
					while (!stack.isEmpty() && !isHigherPrecedence(ch, stack.peek())) {
						sb.append(stack.pop());
					}
					stack.push(ch);
				}
			} else if (isBraces(ch)) {
				if (ch == '(') {
					stack.push(ch);
				} else {
					while (stack.peek() != '(') {
						sb.append(stack.pop());
					}
					stack.pop();
				}
			}
		}

		while (!stack.isEmpty()) {
			sb.append(stack.pop());
		}

		return String.valueOf(sb);
	}

	protected boolean isOperand(int ch) {
		return ch >= 48 && ch <= 57;
	}

	protected boolean isOperator(char ch) {
		return ch == '^' || ch == '*' || ch == '/' || ch == '+' || ch == '-';
	}

	protected boolean isBraces(char ch) {
		return ch == '(' || ch == ')';
	}

	protected boolean isHigherPrecedence(char first, char second) {
		if (first == '*' || first == '/') {
			return second == '+' || second == '-';
		} else if (first == '^') {
			return second == '*' || second == '/' || second == '+' || second == '-';
		}
		return false;
	}

}
