package com.leetcode;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Stack;
import java.util.TreeMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Test {

	public final static void main(String[] args) {
		String input = "java util map";

		Stream<?> s = Stream.of(1, 2, 3, 4, "5");
		List<?> list = s.collect(Collectors.collectingAndThen(Collectors.toList(), l -> {
			Collections.reverse(l);
			return l;
		}));

		List<Integer> ls = Arrays.asList(1, 2, 3, 4, 5);
		Collections.reverse(ls);
		System.out.println(ls);
		
		
//		ls.stream().mapToInt(Integer.parseInt(input)).sum();
		Integer mul = ls.stream().reduce((num1, num2) -> num1 + num2).orElse(-1);
		System.out.println("Mul: " + mul);

		String output1 = Arrays.stream(input.split(" ")).collect(Collectors.collectingAndThen(Collectors.toList(), l -> {
			Collections.reverse(l);
			return l.stream();
		})).collect(Collectors.joining(" "));

		String output2 = Arrays.stream(input.split(" ")).map(st -> new StringBuffer(st).reverse())
				.collect(Collectors.joining(" "));

		System.out.println(list);
		System.out.println(output1);
		System.out.println(output2);

		Integer[] arr = { 1, 2, 3, 4, 6 };
		Arrays.sort(arr, Collections.reverseOrder());
		System.out.println(Arrays.asList(arr));

		List<String> list1 = List.of("sonali", "riya", "omm", "ashwini");
		String longest = list1.stream().sorted(Comparator.comparing(String::length).reversed()).findFirst().get();
		System.out.println(longest);

		String str = "sonali uttam thorat";
//		Set<Character> set = new HashSet<>();
//		String duplicateChars = str.chars().mapToObj(ch -> (char) ch).filter(ch -> !set.add(ch))
//				.collect(Collectors.joining(" "));
		
		int i = 12345;
		int sum = 0;
//		String.valueOf(i).chars().mapToObj(ch -> (

		
		String.valueOf(i).chars().map(Character::getNumericValue).sum();
		
		List<String> list2 = List.of("dog","fog","god","gof","god","fool","gof","loof");
		
		Stack<Character> stack = new Stack<>();
		TreeMap<Integer, Integer> map = new TreeMap<>();
		map.entrySet().stream().map(Map.Entry :: getValue).sorted(Collections.reverseOrder()).findFirst().get();
		
	}
	
	int fetchValue(TreeMap<Integer, Integer> map, int index){
        int sum = 0;
        int lastKey = map.lastKey();
        while(lastKey >= 0 && lastKey <= index){
            sum += map.remove(lastKey);
            lastKey = map.lastKey();
        }

        return sum+2;
    }

}
