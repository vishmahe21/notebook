package com.others;

public class BinarySearchTree {

	Node root;

	public void add(int val) {
		if (root == null) {
			root = new Node(val);
		} else {
			addElement(root, val);
		}
	}

	private void addElement(Node node, int value) {
		if (node == null) {
			node = new Node(value);
			return;
		}

		if (value <= node.value) {
			addElement(node.left, value);
		} else {
			addElement(node.right, value);
		}
	}

	public int height(Node node) {
		if (node == null)
			return 0;
		return Math.max(height(node.left), height(node.right)) + 1;
	}

}

class Node {
	int value;
	Node left;
	Node right;

	public Node(int value) {
		this.value = value;
	}

}
