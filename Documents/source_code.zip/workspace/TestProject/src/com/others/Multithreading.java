package com.others;

public class Multithreading {

	public static void main(String[] args) {

		Thread oddThread = new Thread(new NumberPrinter(true));

		Thread evenThread = new Thread(new NumberPrinter(false));

		oddThread.start();

		evenThread.start();

	}

}

class NumberPrinter implements Runnable {

	private static int counter = 1;

	private boolean isOdd;

	public NumberPrinter(boolean isOdd) {

		this.isOdd = isOdd;

	}

	@Override

	public void run() {

		while (counter <= 10) {

			if ((isOdd && counter % 2 != 0) || (!isOdd && counter % 2 == 0)) {

				System.out.println(counter);

			}

			counter++;

		}

	}

}
