package com.others;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class Test {

	public static void main(String[] args) {
		ArrayList<Integer> numbers = new ArrayList<>(Arrays.asList(1, 2, 56, 78, 30, 40, 99));

		Iterator<Integer> iterator = numbers.iterator();
		while (iterator.hasNext()) {
			if (iterator.next() == 30) {
				iterator.remove(); // ok!
			}
		}

		System.out.println("After iterator.remove(), " + numbers);

		iterator = numbers.iterator();
		while (iterator.hasNext()) {
			if (iterator.next() == 40) {
				numbers.remove(2); // exception
			}
		}

		System.out.println("After Collection.remove(), " + numbers);
	}
}
