package com.others;

import java.util.Map;

public class StudentProxy extends Student {

	public StudentProxy(String name, int regNo, Map<String, String> metadata) {
		super(name, regNo, metadata);
		// TODO Auto-generated constructor stub
	}

	public Student createStudent(Student s) {
		// Do some authentication or authorization
		
		// Add loggers

		Student res = super.createStudent(s);
		// Caching the response to avoid multiple hits to the actual method and send the
		// cached response to user.

		return res;

	}

}
