package com.others;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ExecutorExample {

	public static void main(String[] args) {
		ExecutorService executor = Executors.newCachedThreadPool();
		Task task1 = new Task();
		Task task2 = new Task();
		Task task3 = new Task();
		Task task4 = new Task();
		Task task5 = new Task();
		Task task6 = new Task();
		Task task7 = new Task();
		Task task8 = new Task();
		Task task9 = new Task();
		Task task10 = new Task();
		

		try {
			List<Future<String>> futures = executor
					.invokeAll(Arrays.asList(task1, task2, task3));
//			executor.awaitTermination(2, TimeUnit.MINUTES);
//			executor.shutdownNow();
			executor.execute(() -> System.out.println("Hello World!!"));
			
//			System.out.println(future2.get());
			for (Future<String> future : futures) {
				String result = future.get();
				System.out.println(result);
			}
			

		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}

	}

}

class Task implements Callable<String> {

	@Override
	public String call() throws Exception {
		for (int i = 0; i < 10; i++) {
			System.out.println("Task-" + i + " executed!!");
			Thread.sleep(500);
		}

		return "Success";
	}

}
