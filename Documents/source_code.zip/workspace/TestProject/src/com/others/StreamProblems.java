package com.others;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamProblems {

	public static void main(String[] args) {

		findFourthLargest();

		findLongestString();

		List<Person> persons = Arrays.asList(new Person("Alice", 25, "M"), new Person("Bob", 30, "F"),
				new Person("Charlie", 35, "M"), new Person("Alice", 30, "M"));

		System.out.println(persons.stream().mapToInt(person -> person.age).average().orElse(-1));

		List<Integer> numbers = Arrays.asList(2, 4, 6, 8, 10, 11, 12, 13, 14, 15);
		numbers.stream().anyMatch(i -> i % 2 == 0);

		List<Integer> list1 = Arrays.asList(1, 2, 3, 4, 5);
		List<Integer> list2 = Arrays.asList(3, 4, 5, 6, 7);
		List<Integer> intersect = list1.stream().filter(list2::contains).collect(Collectors.toList());
		System.out.println(intersect);

		System.out.println(
				persons.stream().collect(Collectors.partitioningBy(p -> p.gender == "M", Collectors.counting())));

//		persons.stream().collect(Collectors.groupingBy(Person::getName, Collectors.summingInt(Person::getAge)));

		List<Transaction> transactions = Arrays.asList(new Transaction("2022-01-01", 100),
				new Transaction("2022-01-01", 200), new Transaction("2022-01-02", 300),
				new Transaction("2022-01-02", 400), new Transaction("2022-01-03", 500));

//		Map<String, Integer> sumByDay = transactions
//                .stream()
//                .collect(Collectors.groupingBy(Transaction::getDate,
//                       Collectors.summingInt(Transaction::getAmount)));

		Map<Boolean, List<Integer>> partition = numbers.stream().collect(Collectors.partitioningBy(i -> i % 2 == 0));
		System.out.println("Even no: " + partition.get(true));
		System.out.println("Odd no: " + partition.get(false));

		Map<String, List<Person>> groupByGender = persons.stream().collect(Collectors.groupingBy(p -> p.gender));
		System.out.println(
				"Male Persons: " + groupByGender.get("M").stream().map(p -> p.name).collect(Collectors.toList()));
		System.out.println(
				"Female Persons: " + groupByGender.get("F").stream().map(p -> p.name).collect(Collectors.toList()));

		int num = 12345;
		int digitSum = String.valueOf(num).chars().mapToObj(ch -> Integer.parseInt(String.valueOf((char)ch)))
//				.collect(Collectors.toList());
				.reduce(0, (a, b) -> a + b);
		
		digitSum = String.valueOf(num).chars().map(Character::getNumericValue).sum();
		System.out.println(Integer.parseInt(String.valueOf('1')));
		System.out.println("Sum of digits : " + digitSum);

	}

	private static void findLongestString() {
		// Find longest string
		List<String> strings = Arrays.asList("apple", "banana", "cherry", "date", "grapefruit");
		String longest1 = strings.stream().sorted(Comparator.reverseOrder()).findFirst().get();
		String longest2 = strings.stream().max(Comparator.comparing(String::length)).get();
		// we can also use Comparator.comparingInt
		System.out.println(longest1);
		System.out.println(longest2);
	}

	private static void findCount() {
		List<Integer> list = Arrays.asList(1, 2, 2, 3, 1, 4);
		Map<Integer, Long> countMap = list.stream()
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
	}

	private static void findFourthLargest() {

		String s = "Hello every two nine seven five nineteen";

		// Split the string into words and sort them in descending order by length
		String[] splitted = s.split(" ");
		Arrays.sort(splitted, Comparator.comparingInt(String::length).reversed());

		// Use a Stream to efficiently find the fourth-longest word
		Stream<String> wordStream = Arrays.stream(splitted);
		String fourthLongest = wordStream.distinct() // Remove duplicate lengths
				.skip(3) // Skip the first three distinct lengths
				.findFirst() // Find the fourth distinct length
				.orElse(null); // Handle empty stream case

		System.out.println(fourthLongest);

		Map<Integer, List<String>> map = Arrays.stream(splitted)
				.collect(Collectors.groupingBy(String::length, Collectors.toList()));
		map.get(map.entrySet().stream().map(Map.Entry::getKey).sorted(Comparator.reverseOrder()).skip(3).findFirst()
				.get());

//		String s = "Hello every two nine seven five nineteen";
//		String[] splitted = s.split(" ");
//		Arrays.sort(splitted, Comparator.comparingInt(String::length).reversed());
//		int count = 1;
//		String fourthLongest = null;
//		for(int i=1; i<splitted.length; i++) {
//			if(splitted[i].length() != splitted[i-1].length()) {
//				count++;
//			}
//			if(count == 4) {
//				fourthLongest = splitted[i];
//				break;
//			}
//		}
//		
//		System.out.println(fourthLongest);
//		
//		List<String> longest = Arrays.stream(s.split(" "))
//				.collect(Collectors.collectingAndThen(Collectors.groupingBy(String::length, Collectors.toList()),
//						map -> map.entrySet().stream()))
//				.sorted(Comparator.comparingInt(Map.Entry::get)  .reversed()).skip(3).findFirst().get().getValue();
//

	}

}

class Person {
	String name;
	int age;
	String gender;

	public Person(String name, int age, String gender) {
		this.name = name;
		this.age = age;
		this.gender = gender;
	}
}

class Transaction {
	String date;
	int amount;

	public Transaction(String date, int amount) {
		this.date = date;
		this.amount = amount;
	}

}
