package com.others;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

public class CompletableFutureExample {

	public static void main(String[] args) throws InterruptedException, ExecutionException {

		CompletableFuture<String> future = CompletableFuture.supplyAsync(() -> "Hello")
				.thenApply(s -> s.concat(" World")).thenApplyAsync(s -> s.concat(" Next"));

		System.out.println(future.get());

		List<Integer> ls = Arrays.asList(1, 2, 3, 4, 5);
//		List<Integer> res = ls.stream().map(num -> {
//			CompletableFuture.supplyAsync(() -> num * num).thenApply(n -> n + n).thenApplyAsync(n -> n + n)
//					.thenApply(n -> n + n);
//
//		}).collect(Collectors.toList());

//		System.out.println("List: " + res);

		String s = "1";

		CompletableFuture<Boolean> future3 = CompletableFuture.supplyAsync(() -> s.equals("2"))
				.exceptionally(ex -> !ex.getMessage().equals(null));

//		CompletableFuture<Object> future4 = CompletableFuture.supplyAsync(() -> s.equals("2")).handle((b, ex) -> ex.getMessage().concat(String.valueOf(b)));
		System.out.println(future3.get());
//		System.out.println(future4.get());

	}

}
