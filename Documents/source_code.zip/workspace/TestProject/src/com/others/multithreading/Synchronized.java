package com.others.multithreading;

public class Synchronized {

	private static String message;

	public static void main(String[] args) {

//		Thread.currentThread().interrupt();

		Synchronized obj = new Synchronized();

		Runnable r = new Runnable() {
			public void run() {
				obj.method1();
				obj.method2();
			}
		};

		Thread t1 = new Thread(r);
		t1.setName("thread1");
		Thread t2 = new Thread(r);
		t2.setName("thread2");
		Thread t3 = new Thread(r);
		t3.setName("thread3");
		Thread t4 = new Thread(r);
		t4.setName("thread4");
		t1.start();
		t2.start();
		t3.start();
		t4.start();

	}

	protected synchronized void method1() {
		System.out.println(Thread.currentThread().getName() + " is executing method1");

	}

	protected void method2() {
		synchronized (this) {
		System.out.println(Thread.currentThread().getName() + " is executing block in method2");
		}

		System.out.println(Thread.currentThread().getName() + " is executing in method2");
	}

	class A implements Runnable {
		@Override
		public void run() {
			Synchronized obj = new Synchronized();
			obj.message = "thread1";
			obj.method1();
			obj.method2();
		}
	}

	class B implements Runnable {
		@Override
		public void run() {
			Synchronized obj = new Synchronized();
			obj.message = "thread2";
			obj.method1();
			obj.method2();
		}
	}

}
