package com.others;

import java.text.NumberFormat;
import java.util.Currency;
import java.util.Locale;

public class LoanCalculator {

	static double amountPaid = 0;
	static NumberFormat rupayFormat = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
//	String formattedAmount = rupayFormat.format(amountPaid);

	public static void main(String[] args) {

		double principal = 8000000;
		double interest = 8.5;
		double monthlyPay = 100000;
		double monthlyPayIncrement = 5;

		calculateLoan(principal, interest, monthlyPay, monthlyPayIncrement);

	}

	private static void calculateLoan(double principal, double interest, double monthlyPay,
			double monthlyPayIncrement) {
		double amountLeft = principal;
		int iteration = 0;
		int yearCount = 0;

		while (amountLeft >= 0) {
			iteration++;
			amountLeft -= monthlyPay;
			amountLeft += amountLeft * (interest / 1200);
			if (iteration % 12 == 0) {
				yearCount++;
				System.out.println(
						String.format("Amount left after %d years: %s", yearCount, rupayFormat.format(amountLeft)));
				amountPaid += monthlyPay * 12;
				monthlyPay += monthlyPay * monthlyPayIncrement / 100;
			}
		}

		System.out.println(String.format("Amount left after %dy%dm years: %s", yearCount, iteration % 12,
				rupayFormat.format(amountLeft)));

		amountPaid += monthlyPay * (iteration % 12) + amountLeft;

		System.out.println(String.format("Total amount paid: %s", rupayFormat.format(amountPaid)));

	}

}
