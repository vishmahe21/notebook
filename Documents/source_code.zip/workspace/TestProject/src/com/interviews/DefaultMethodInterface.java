package com.interviews;

public class DefaultMethodInterface {
	
	

}



interface A {
	public abstract int find();
	
	default void grow() {
		System.out.println("Default method of interface A");
	}
	
}

interface B {
	public abstract int find();
	
	default void grow() {
		System.out.println("Default method of interface B");
	}
	
}


class Test implements A, B{

	@Override
	public int find() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void grow() {
		// TODO Auto-generated method stub
		B.super.grow();
	}

	
}

