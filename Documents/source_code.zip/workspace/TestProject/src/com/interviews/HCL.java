package com.interviews;

import java.io.IOException;

class HCL {

	public static void main(String[] args) {

		new Second(2);

	}

}

class First {
	int a;

	public First(int a) {
		System.out.println("Calling First parameterized constructor");
	}

	public First() {
		System.out.println("Calling First default constructor");
	}

	public void method1() throws IOException {

	}
}

class Second extends First {
	public Second(int a) {
		System.out.println("Calling Second constructor");
	}

	public void method1() throws IOException {

	}
}
