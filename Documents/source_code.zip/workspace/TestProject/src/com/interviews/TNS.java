package com.interviews;

public class TNS {
	
	

}

class Student{
	
}
