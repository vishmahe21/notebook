package com.interviews;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Employee {

	int id;
	String name;
	String gender;
	int salary;

	public Employee(int id, String name, String gender, int salary) {
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.salary = salary;
	}

	public int getSalary() {
		return this.salary;
	}

	public String getName() {
		return this.name;
	}

	public String toString() {
		return String.format("id: %d, name: %s, gender: %s, salary:%d", id, name, gender, salary);
	}

	public static void main(String[] args) {

		List<Employee> list = new ArrayList<>();
		Employee e1 = new Employee(1, "e1", "M", 10000);
		Employee e2 = new Employee(1, "e2", "M", 20000);
		Employee e3 = new Employee(1, "e3", "F", 50000);
		Employee e4 = new Employee(1, "e4", "F", 30000);
		Employee e5 = new Employee(1, "e5", "M", 40000);

		list.add(e1);
		list.add(e2);
		list.add(e3);
		list.add(e4);
		list.add(e5);

		list.stream().map(Employee::getSalary).sorted(Comparator.reverseOrder()).skip(1).findFirst();
		int salary = list.stream().sorted(Comparator.comparingInt(Employee::getSalary).reversed()).skip(1)
				.map(Employee::getSalary).findFirst().get();
		System.out.println(salary);

		Map<String, Double> averageSalaryMap = list.stream()
				.collect(Collectors.groupingBy(e -> e.gender, Collectors.averagingInt(e -> e.salary)));

		System.out.println(averageSalaryMap);
	}

	public Employee getEmployeeById(Integer id) throws EmployeeException {

		if (id != null) {
			throw new EmployeeException("id should not be null");
		}

		return null;
	}

}

class EmployeeException extends Exception {

	private String message;

	public EmployeeException(String message) {
		super(message);
	}

}
