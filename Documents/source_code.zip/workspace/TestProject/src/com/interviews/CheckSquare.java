package com.interviews;

public class CheckSquare {

	public static void main(String[] args) {
		int len = solution(3, 16);
		System.out.println(len);
	}

	static int countPieces(int length, int stick1, int stick2) {
		return (stick1 / length) + (stick2 / length);
	}

	static boolean canFormSquare(int length, int stick1, int stick2) {
		return countPieces(length, stick1, stick2) >= 4;
	}

	public static int solution(int A, int B) {
		int length = Math.max(Math.min(A, B), Math.max(A, B) / 4);
		for (; length > 0; length--) {
			if (canFormSquare(length, A, B)) {
				return length;
			}
		}
		return 0;
	}

}
