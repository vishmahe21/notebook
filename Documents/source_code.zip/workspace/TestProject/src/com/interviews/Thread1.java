package com.interviews;

class Thread1 extends Thread {
	public void run() {
		System.out.print("Hello...");
	}

	public static void main(String args[]) throws InterruptedException {
		Thread1 T1 = new Thread1();
		T1.start();
//		T1.stop();
		Thread.sleep(5000);
		T1.start();
	}
}
