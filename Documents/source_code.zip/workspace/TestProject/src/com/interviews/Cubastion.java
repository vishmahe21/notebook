package com.interviews;

import java.util.List;

public class Cubastion {
	public static void main(String[] args) {
		
		List<Car> list = List.of();
		
	}

}

class Car{
	int id;
	String companyName;
	String engineNo;
	
	public Car(int id, String companyName, String engineNo) {
		this.id = id;
		this.companyName = companyName;
		this.engineNo = engineNo;
	}
}


