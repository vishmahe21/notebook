package com.interviews;

public class TryCatch {

	public static void main(String[] args) {
		System.out.println(sampleMethod());
	}

	static String sampleMethod() {
		try {
//			int i = 10 / 0;
			System.out.println("executing try");
			return "Success";

		} catch (Exception ex) {
			System.out.println("executing catch");
			return "Failure";

		} finally {
			System.out.println("executing finally");
			return "Finally";
		}
	}

}
