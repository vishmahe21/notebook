package com.test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import com.interviews.Employee;

public class Test14 {

	enum Gender {
		MALE, FEMALE
	}

	public static void main(String[] args) {

		List<Employee> list = new ArrayList<>();

		list.add(new Employee(1, "Ram", Gender.MALE.name(), 10000));
		list.add(new Employee(2, "Shyam", Gender.MALE.name(), 15000));
		list.add(new Employee(3, "Ram", Gender.MALE.name(), 5000));
		list.add(new Employee(4, "Chandrika", Gender.FEMALE.name(), 30000));
		list.add(new Employee(5, "Rishabh", Gender.MALE.name(), 70000));
		list.add(new Employee(6, "Madhavi", Gender.FEMALE.name(), 90000));
		list.add(new Employee(7, "Krishna", Gender.MALE.name(), 50000));
		list.add(new Employee(8, "Kamini", Gender.FEMALE.name(), 80000));
		list.add(new Employee(9, "Krishna", Gender.MALE.name(), 20000));
		list.add(new Employee(10, "Anamika", Gender.FEMALE.name(), 12000));

		list.stream().sorted(Comparator.comparing(Employee::getName).thenComparing(Employee::getSalary))
				.forEach(System.out::println);

	}

}
