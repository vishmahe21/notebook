package com.test;

public class Test2 {

	public static void main(String[] args) {

		String s = "abbbccddaaabbccceeff";

		StringBuilder sb = new StringBuilder();

		char[] ch = s.toCharArray();

//		int i = 0;
//		char previous = ch[0];
//		int count = 0;
//		sb.append(previous);
//		while(i < s.length()) {
//			if(ch[i] == previous) {
//				count++;
//			}else {
//				sb.append(String.valueOf(count));
//				count = 1;
//				sb.append(ch[i]);
//			}
//			previous = ch[i];
//			i++;
//		}
//		sb.append(String.valueOf(count));

		sb.append(ch[0]);
		int j = 0;
		for (int i = 1; i < ch.length; i++) {
			if (ch[i] != ch[i - 1]) {
				sb.append(String.valueOf(i - j));
				j = i;
				sb.append(ch[i]);
			}
		}

		sb.append(ch.length - j);

		System.out.println(sb.toString());
		

	}

}
