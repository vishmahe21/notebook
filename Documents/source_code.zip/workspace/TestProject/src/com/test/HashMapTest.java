package com.test;

import java.util.HashMap;
import java.util.Map;

public class HashMapTest {

	public static void main(String[] args) {
		HashMap<Employee, String> map = new HashMap();
		Employee emp1 = new Employee(1, "Pavan");
		Employee emp2 = new Employee(2, "Mahesh");
		Employee emp3 = new Employee(3, "Sourabh");
		Employee emp4 = new Employee(4, "Rishabh");
		Employee emp5 = new Employee(5, "Nitin");

		map.put(emp1, emp1.name);
		map.put(emp2, emp2.name);
		map.put(emp3, emp3.name);
		map.put(emp4, emp4.name);
		map.put(emp5, emp5.name);

//		for(Map.Entry<Employee, String> entry : map.entrySet()) {
//			System.out.println(entry.);
//		}

		System.out.println(map);
	}

}

class Employee {
	int id;
	String name;

	public Employee(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public String toString() {
		return String.format("id: %d, name: %s", id, name);
	}

}
