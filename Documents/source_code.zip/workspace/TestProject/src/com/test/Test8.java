package com.test;

import java.util.Stack;

public class Test8 {

	public static void main(String[] args) {

		Stack<Integer> arr = new Stack<>();
		arr.push(1);
		arr.push(2);
		arr.push(3);
		arr.push(4);
		arr.push(5);
//		arr.push(6);

		int len = arr.size();

//		for (int i = 0; i < len / 2; i++) {
//			arr.pop();
//		}
//
//		System.out.println(arr.peek());
		
		System.out.println(arr.get((len-1)/2));
	}
}
