package com.test;

import java.util.Arrays;
import java.util.stream.Collectors;

public class Test9 {

	public static void main(String[] args) {

		String s = "Hello World";

		// res = olleH dlroW

		String[] splitted = s.split(" ");

		String res = Arrays.stream(splitted).map(i -> reverse(i)).collect(Collectors.joining(" "));

		System.out.println(res);

	}

	static String reverse(String input) {
		char[] arr = input.toCharArray();
		int len = arr.length;

		for (int i = 0; i < len / 2; i++) {
			char temp = arr[i];
			arr[i] = arr[len - 1 - i];
			arr[len - 1 - i] = temp;
		}

		return String.valueOf(arr);

	}

}
