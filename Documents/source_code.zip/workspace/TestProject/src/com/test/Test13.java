package com.test;

public class Test13 {

	public static void main(String[] args) throws InterruptedException {

		Runnable t = () -> System.out.println("Hello World");

		Thread th = new Thread(t);

		th.start();

//		Thread.sleep(600000);
//		System.out.println(Thread.interrupted());
//		Thread.currentThread().interrupt();
//		try {
//			Thread.sleep(600000);
//		} catch(InterruptedException e) {
//			e.printStackTrace();
//		}
		
		th.join();
		System.out.println("Hello after 10mins");
		System.out.println("Hello after 10mins");
		System.out.println("Hello after 10mins");
		System.out.println("Hello after 10mins");
		System.out.println("Hello after 10mins");

		// list of employees --> dept

//		List<Employee> list = new ArrayList<>();
//		
//		Map<String, List<Employee>> res = list.stream().collect(Collectors.groupingBy(e -> e.dept, Collectors.toList()));
//		

	}

	class Employee {

		public int id;
		String dept;
	}

}
