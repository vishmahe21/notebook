package com.test;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Test4 {

	public static void main(String[] args) {

		List<Integer> li = List.of(1, 2, 3, 4, 5, 4, 3, 2, 1, 8, 9, 7);

		int large = li.stream().sorted(Collections.reverseOrder()).skip(2).findFirst().get();

		System.out.println(large);

		String s = "bangalore";

		Map<Character, Long> countMap = s.chars().mapToObj(ch -> (char) ch)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		System.out.println(countMap);

	}

}
