package com.test;

public class Test3 {

	public static void main(String[] args) {
		
		String s = "a12b13c2d2a3b2c3e2f1";
		
		char ch[] = s.toCharArray();
		
		StringBuilder sb = new StringBuilder();
		StringBuilder num = new StringBuilder();
		
		for(int i=0; i<ch.length; i++) {
			if(!isNumber(ch[i])) {
				if(!num.isEmpty()) {
					int count = Integer.parseInt(num.toString());
					char previous = sb.charAt(sb.length()-1);
					for(int j=0; j<count-1; j++) {
						sb.append(previous);
					}
					num.delete(0, sb.length());
				}
				
				
				sb.append(ch[i]);
			} else {
				num.append(ch[i]);
			}
		}
		
		int count = Integer.parseInt(num.toString());
		char previous = sb.charAt(sb.length()-1);
		for(int j=0; j<count-1; j++) {
			sb.append(previous);
		}
		
		System.out.println(sb.toString());
	

	}
	
	private static boolean isNumber(char chs) {
		return chs >=49 && chs <= 57;
	}

}
