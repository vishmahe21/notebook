package com.test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.stream.Collectors;

public class Test12 {

	public static void main(String[] args) {
		String s = "pwwkesaw";

		char[] arr = s.toCharArray();
		int i = 0;
		HashSet<Character> set = new HashSet<>();
		int max = 0;

		for (int j = 0; j < arr.length; j++) {
			if (set.contains(arr[j])) {
				int count = j - i;
				max = count > max ? count : max;
				i = j;
			}
			set.add(arr[j]);
		}

		int count = arr.length - i;
		max = count > max ? count : max;

		System.out.println(max);
	}

}
