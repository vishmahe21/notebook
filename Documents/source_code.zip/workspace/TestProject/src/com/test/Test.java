package com.test;

import java.util.Arrays;

public class Test {

	public static void main(String[] args) {
		
		int[] arr = {-1, 2, -3, 4, 5, 6, -7, 8, 9};
		
		Arrays.sort(arr);
		
		int len = arr.length;
		
		int i= len-1;
		int j = 0;
		
		int[] res = new int[len];
		int k = 0;
		
//		while(j < i) {
//			if(arr[i] >= 0) {
//				res[k++] = arr[i--];
//			} else {
//				break;
//			}
//			if(arr[j] < 0) {
//				res[k++] = arr[j++];
//			} else {
//				break;
//			}
//		}
//		
//		for(int m = j; m <= i; m++) {
//			res[k++] = arr[m];
//		}
		
		while(j < i) {
			res[k++] = arr[i--];
			res[k++] = arr[j++];
		}
		
		for(int m=0; m< res.length; m++) {
			System.out.print(res[m] + ", ");
		}
		
		
		
	}

}
