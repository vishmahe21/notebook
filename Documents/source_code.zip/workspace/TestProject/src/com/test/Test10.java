package com.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Test10 {

	public static void main(String[] args) {
		List<Employees> empList = new ArrayList<>();
		empList.add(new Employees(1, "emp1", 10000.00));
		empList.add(new Employees(2, "emp2", 20000.00));
		empList.add(new Employees(3, "emp3", 30000.00));
		empList.add(new Employees(4, "emp4", 10000.00));
		empList.add(new Employees(5, "emp5", 10000.00));
		empList.add(new Employees(6, "emp6", 20000.00));
		empList.add(new Employees(7, "emp7", 30000.00));

//		empList.stream().collect(Collectors.toMap(e -> e.salary, ));

		empList.stream().map(Employees::getName).collect(Collectors.toList());

		Map<Double, List<String>> groupBySalary = empList.stream().collect(Collectors.groupingBy(Employees::getSalary,
				Collectors.mapping(Employees::getName, Collectors.toList())));

		Map<Double, String> groupBySalary2 = empList.stream()
				.collect(Collectors.toMap(Employees::getSalary, Employees::getName, (a, b) -> a + "," + b));

		System.out.println("groupBySalary: " + groupBySalary);
		System.out.println("groupBySalary2: " + groupBySalary2);

		List<Integer> list = Arrays.asList(22, 34, 54, 67, 89);

		List<Integer> evenNoList = list.stream().filter(Test10::validateEven).collect(Collectors.toList());
		System.out.println(evenNoList);

	}

	static boolean validateEven(int n) {
		return n % 2 == 0;
	}

}

class Employees {
	int id;
	String name;
	double salary;

	public Employees(int id, String name, double salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public double getSalary() {
		return salary;
	}

}
