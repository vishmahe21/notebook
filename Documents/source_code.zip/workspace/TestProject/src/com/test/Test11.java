package com.test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Test11 {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 9, 10);

		Map<Boolean, List<Integer>> map = list.stream()
				.collect(Collectors.partitioningBy(i -> i % 2 == 0, Collectors.toList()));
		
		Map<Boolean, Integer> map1 = list.stream()
				.collect(Collectors.partitioningBy(i -> i % 2 == 0, Collectors.summingInt(i -> i)));

		int evenSum = map.get(true).stream().reduce((a, b) -> a + b).get();

		int oddSum = map.get(false).stream().reduce((a, b) -> a + b).get();

		System.out.println(evenSum);
		System.out.println(oddSum);
		
		System.out.println(map1.get(true));
		System.out.println(map1.get(false));

	}

}
