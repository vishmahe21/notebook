package com.test;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Test6 {

	public static void main(String[] args) {
		String s = "vishwas maheshwari";

		List<Character> collect = s.chars().mapToObj(c -> (char) c)
				.collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()))
				.entrySet().stream().filter(e -> e.getValue() == 1).map(e -> e.getKey()).collect(Collectors.toList());

		System.out.println(collect);

		List<String> list = List.of("sonali", "riya", "omm", "ashwini");

		String longest = list.stream().sorted(Comparator.comparingInt(String::length).reversed()).findFirst().get();
		String longest1 = list.stream().reduce((w1, w2) -> w1.length() > w2.length() ? w1 : w2).get();
		String combined = list.stream().reduce((w1, w2) -> w1 + "-" + w2).get();

		System.out.println(longest + " " + longest1);
		System.out.println(combined);

		List<Integer> list1 = List.of(1, 2, 3, 4, 5);

		int sum1 = list1.stream().mapToInt(i -> i).sum();
		int sum2 = list1.stream().reduce((a, b) -> a * b).get();

		System.out.println(sum1 + " " + sum2);

	}

}
