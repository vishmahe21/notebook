package com.test;

import java.util.Arrays;
import java.util.LinkedList;

public class Test7 {

	public static void main(String[] args) {

		LinkedList<Integer> list = new LinkedList<>(Arrays.asList(0, 1, 0, 1, 1));

		int length = list.size();
		double num = 0;

		for (int i = 0; i < length; i++) {
			if (list.get(i) == 1) {
				num += Math.pow(2, length - 1 - i);
			}

		}

		System.out.println(num);
	}

}
