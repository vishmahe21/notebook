package com.test;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Test15 {
	
	public static void main(String[] args) {
		int[] a = {1,2,5,4,0};
		int[] b = {2,4,5,0,1};
		
		// sort them and compare from 0 to n step by step
		
//		Arrays.sort(a);
//		Arrays.sort(b);
		
		Map<Integer, Long> countA = Arrays.stream(a).boxed().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		Map<Integer, Long> countB = Arrays.stream(b).boxed().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		
		for(Map.Entry<Integer, Long> entry : countA.entrySet()) {
			if(!entry.getValue().equals(countB.get(entry.getKey()))) {
				System.out.println(false);
				return;
			}
		}
		
		System.out.println(true);
		
	}

}
